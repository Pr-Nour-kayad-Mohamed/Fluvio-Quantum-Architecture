Place ici les 6 blueprints WEBP téléchargés depuis WhatsApp:
- image_20261027_005455.webp (Cover)
- image_20261027_005249.webp (1.1+1.3 Madelung + Strange Metals)
- image_20261027_004827.webp (1.2 Bohm Q)
- image_20261027_005245.webp (1.4 Tenseur M0)
- image_20261027_004159.webp (3.1 Gradient Flow V_BHK)
- image_20261027_003934.webp (3.2 Loss Cone)
- image_20261027_004332.webp (3.3 Frama-C SCCI-2026)
- Fluvio_Global_TOC.png (Table des matieres)
